<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestSuite_HTEC4_Edit</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2019-12-03T03:58:29</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>f7f11847-aa42-4af8-9401-efab6c5e8c6e</testSuiteGuid>
   <testCaseLink>
      <guid>807937b7-5236-4294-acbc-c5510ff2ddc3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_Edit_UseCase_properties</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
