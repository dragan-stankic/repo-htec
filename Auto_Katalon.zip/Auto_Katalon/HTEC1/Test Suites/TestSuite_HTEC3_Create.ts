<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestSuite_HTEC3_Create</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2019-12-03T03:54:57</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>9b345cda-f9a2-4636-a7c4-759f7c755607</testSuiteGuid>
   <testCaseLink>
      <guid>6b7c8290-09b4-4b6f-b1a1-f793e72e5419</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_Create_UseCase_records</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
