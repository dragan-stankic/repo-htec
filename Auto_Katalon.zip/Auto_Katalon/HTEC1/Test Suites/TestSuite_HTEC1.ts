<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestSuite_HTEC1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2019-12-03T04:32:09</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>52ad3dfe-2cde-4250-9c2e-fe7811057cdc</testSuiteGuid>
   <testCaseLink>
      <guid>85634c86-381d-4264-a222-30b009149318</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_Create_UseCase_records</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a2fa2e78-b63f-4ffd-a8e1-6266dbe73730</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_Edit_UseCase_properties</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fb962df0-26c2-4eb7-b0e5-5c2aa365d4a9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_Delete_UseCase_records</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f563a3d2-f36e-4979-9895-47c1589542d2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_Create_UseCase_records</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1361da1a-f3f7-4242-a73f-8ffb1a8901fb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/TC_Delete_UseCase_records</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
