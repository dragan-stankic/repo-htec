<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestSuite_HTEC2_Delete</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2019-12-03T04:38:22</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>2c79ffa8-9508-49e0-b3fb-ce3cd41f4328</testSuiteGuid>
   <testCaseLink>
      <guid>db57aaf0-9c19-4ddb-b87a-ca3572199995</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_Delete_UseCase_records</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
