import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testdata.ExcelData
import com.kms.katalon.core.testobject.ConditionType

// Data driven test - copy Use cases from Excel table 
ExcelData data = findTestData('Excel_TC_list2')

// Open browser and navigate to URL to be tested (AUT) 
WebUI.openBrowser('')

WebUI.navigateToUrl('https://qa-sandbox.apps.htec.rs/')

// Do Login 
WebUI.click(findTestObject('Page_Sandbox/a_Login'))

WebUI.setText(findTestObject('Page_Sandbox/input_Log In_email'), 'dragan.stankic@gmail.com')

WebUI.setEncryptedText(findTestObject('Page_Sandbox/input_Log In_password'), '7yNAhyZfJovLPv5wBPwDxw==')

WebUI.click(findTestObject('Page_Sandbox/button_Submit'))

WebUI.click(findTestObject('Page_Sandbox/img_Profile updated_card-img-t'))


// Loop to Delete ALL Use cases  ( improvement would be to obtain number of Use cases from the Use-cases page  )   
for (def index : (data.getRowNumbers()..1)) {

	// In Katalon, DYNAMIC objects, that are NOT in ObjectRepository ( originally initialized using "Recording" feature), 
	// should be referenced using temporary Object
	// Object is initilized using "xpath" to the specific element in the list of Use cases
	//DS from https://forum.katalon.com/t/findtestobject-name-marketid-returns-null/16106/2
	TestObject to
	to = new TestObject().addProperty('xpath', ConditionType.CONTAINS, '//*[@id="root"]/div/div[2]/div/div/a['+index+']')
	// Click to edit specific Use case
	WebUI.click(to)

	// Click Delete button + Confirm  
	WebUI.click(findTestObject('Page_Sandbox/i_Edit Use Case_far fa-trash-a'))
	WebUI.click(findTestObject('Page_Sandbox/button_Delete'))
}

// Do Logout ( wait for object on the page to be visable) 
WebUI.waitForElementVisible(findTestObject('Page_Sandbox/a_Logout'), 10)
WebUI.click(findTestObject('Page_Sandbox/a_Logout'))

// Close browser 
WebUI.closeBrowser()

